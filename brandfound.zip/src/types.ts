export type Category = 'Beauty' | 'Toys' | 'Tech' | 'Fashion' | 'Home' | 'Gaming';

export interface Product {
  id: string;
  brand: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  reviews: number;
  store: string;
  category: Category;
  inStock: boolean;
  tags: string[];
  specs: Record<string, string>;
}

export interface PriceAlert {
  id: string;
  productId: string;
  targetPrice: number;
  addedAt: number;
}
