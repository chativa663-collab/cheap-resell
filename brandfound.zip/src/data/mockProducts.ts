import { Product } from '../types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    brand: 'Beauty of Joseon',
    name: 'Relief Sun : Rice + Probiotics (SPF50+ PA++++)',
    price: 11.99,
    originalPrice: 18.00,
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=400',
    rating: 4.8,
    reviews: 1250,
    store: 'Olive Young',
    category: 'Beauty',
    inStock: true,
    tags: ['Korean', 'Rice', 'Lightweight'],
    specs: {
      'SPF': '50+',
      'PA': '++++',
      'Volume': '50ml',
      'Skin Type': 'All Skin Types'
    }
  },
  {
    id: '2',
    brand: 'Round Lab',
    name: 'Birch Juice Moisturizing Sunscreen',
    price: 14.50,
    originalPrice: 21.00,
    image: 'https://images.unsplash.com/photo-1616683693504-3ea7e9ad6fec?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviews: 3200,
    store: 'Stylevana',
    category: 'Beauty',
    inStock: true,
    tags: ['Korean', 'Hydrating', 'Birch Juice'],
    specs: {
      'SPF': '50+',
      'PA': '++++',
      'Volume': '50ml',
      'Skin Type': 'Dry/Sensitive'
    }
  },
  {
    id: '3',
    brand: 'COSRX',
    name: 'Aloe Soothing Sun Cream',
    price: 9.80,
    originalPrice: 14.00,
    image: 'https://images.unsplash.com/photo-1624454002302-36b824d7bd0a?auto=format&fit=crop&q=80&w=400',
    rating: 4.6,
    reviews: 2100,
    store: 'YesStyle',
    category: 'Beauty',
    inStock: true,
    tags: ['Aloe', 'Soothing'],
    specs: {
      'SPF': '50+',
      'PA': '+++',
      'Volume': '50ml',
      'Skin Type': 'Sensitive'
    }
  },
  {
    id: '4',
    brand: 'Skin1004',
    name: 'Madagascar Centella Hyalu-Cica Water-Fit Sun Serum',
    price: 12.00,
    originalPrice: 19.00,
    image: 'https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviews: 890,
    store: 'Olive Young',
    category: 'Beauty',
    inStock: false,
    tags: ['Centella', 'Serum Texture'],
    specs: {
      'SPF': '50+',
      'PA': '++++',
      'Volume': '50ml',
      'Skin Type': 'Oily/Combination'
    }
  },
  {
    id: '5',
    brand: 'Nintendo',
    name: 'Switch OLED Model - White',
    price: 299.00,
    originalPrice: 349.99,
    image: 'https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviews: 8900,
    store: 'Target',
    category: 'Gaming',
    inStock: true,
    tags: ['OLED', 'Handheld', 'Gaming'],
    specs: {
      'Screen': '7-inch OLED',
      'Storage': '64GB',
      'Battery': 'Up to 9h'
    }
  },
  {
    id: '6',
    brand: 'LEGO',
    name: 'Star Wars Millenium Falcon',
    price: 139.99,
    originalPrice: 169.99,
    image: 'https://images.unsplash.com/photo-1585366119957-e9730b6d0f60?auto=format&fit=crop&q=80&w=400',
    rating: 4.8,
    reviews: 1250,
    store: 'Amazon',
    category: 'Toys',
    inStock: true,
    tags: ['Building', 'Collector', 'Gift'],
    specs: {
      'Pieces': '1351',
      'Age': '9+',
      'Theme': 'Star Wars'
    }
  },
  {
    id: '7',
    brand: 'Nike',
    name: 'Air Jordan 1 Low',
    price: 85.00,
    originalPrice: 110.00,
    image: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&q=80&w=400',
    rating: 4.7,
    reviews: 3200,
    store: 'Nike Store',
    category: 'Fashion',
    inStock: true,
    tags: ['Retro', 'Leather', 'Limited'],
    specs: {
      'Material': 'Genuine Leather',
      'Outsole': 'Rubber',
      'Style': 'Low-top'
    }
  },
  {
    id: '8',
    brand: 'Dyson',
    name: 'V15 Detect Cordless Vacuum',
    price: 549.00,
    originalPrice: 749.99,
    image: 'https://images.unsplash.com/photo-1558317374-067df5f14875?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviews: 4500,
    store: 'Best Buy',
    category: 'Home',
    inStock: true,
    tags: ['Smart', 'Cordless', 'Suction'],
    specs: {
      'Runtime': '60 min',
      'Suction': '230 AW',
      'Filter': 'HEPA'
    }
  }
];
