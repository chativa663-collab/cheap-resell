import { X, ExternalLink, Bell, Star, AlertCircle } from 'lucide-react';
import { Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface DetailModalProps {
  product: Product | null;
  onClose: () => void;
}

export default function DetailModal({ product, onClose }: DetailModalProps) {
  if (!product) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          id="modal-backdrop"
        />
        
        <motion.div 
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-xl bg-white rounded-t-[2.5rem] sm:rounded-[2.5rem] overflow-hidden shadow-2xl h-[90vh] sm:h-auto overflow-y-auto no-scrollbar"
          id="modal-content"
        >
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 z-10 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-lg text-gray-900 border border-black/5"
            id="close-modal-btn"
          >
            <X size={20} />
          </button>

          <div className="aspect-[4/3] sm:aspect-video overflow-hidden">
            <img 
              src={product.image} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-8">
            <div className="flex items-center gap-2 mb-4">
              <span className="px-3 py-1 bg-brand-accent/10 border border-brand-accent/20 text-brand-accent text-[10px] font-bold uppercase tracking-widest rounded-full">
                {product.category}
              </span>
              <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                <Star size={14} className="text-yellow-400 fill-yellow-400" />
                <span>{product.rating}</span>
                <span className="text-gray-400 font-medium">({product.reviews} reviews)</span>
              </div>
            </div>

            <div className="mb-6">
              <h4 className="text-xs font-bold text-brand-accent uppercase tracking-[0.2em] mb-1">{product.brand}</h4>
              <h2 className="text-2xl font-bold text-gray-900 leading-tight mb-4">{product.name}</h2>
              
              <div className="flex items-center gap-4">
                <div className="flex flex-col">
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Best Price at {product.store}</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-gray-900">${product.price.toFixed(2)}</span>
                    {product.originalPrice && (
                      <span className="text-lg text-gray-400 line-through font-medium">${product.originalPrice.toFixed(2)}</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {!product.inStock && (
              <div className="mb-6 p-4 bg-red-50 border border-red-100 rounded-2xl flex gap-3 text-red-600">
                <AlertCircle className="shrink-0" size={20} />
                <div className="text-xs">
                  <p className="font-bold">Currently Out of Stock</p>
                  <p className="opacity-80">We can notify you as soon as this item is back in stock at this price.</p>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4 mb-8">
              {Object.entries(product.specs).map(([key, value]) => (
                <div key={key} className="p-4 bg-gray-50 rounded-2xl border border-black/5">
                  <span className="block text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">{key}</span>
                  <span className="text-xs font-bold text-gray-900">{value}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col gap-3">
              <button 
                className="w-full bg-brand-primary text-white py-4 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 hover:bg-gray-800 transition-all shadow-xl shadow-black/10"
                id="buy-now-btn"
              >
                Go to {product.store}
                <ExternalLink size={16} />
              </button>
              
              <button 
                className="w-full bg-white text-gray-900 border border-black/5 py-4 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 hover:bg-gray-50 transition-all"
                id="price-alert-btn"
              >
                <Bell size={16} />
                Set Price Alert
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
