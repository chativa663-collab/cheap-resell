import { Heart, Star, Bell, ArrowLeftRight } from 'lucide-react';
import { Product } from '../types';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onSelect: (product: Product) => void;
  onToggleCompare: (product: Product) => void;
  isComparing: boolean;
}

export default function ProductCard({ 
  product, 
  isFavorite, 
  onToggleFavorite, 
  onSelect,
  onToggleCompare,
  isComparing 
}: ProductCardProps) {
  const discount = product.originalPrice 
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl overflow-hidden shadow-sm border border-black/5 hover:shadow-md transition-shadow group flex flex-col h-full"
      id={`product-card-${product.id}`}
    >
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 cursor-pointer"
          onClick={() => onSelect(product)}
        />
        
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onToggleFavorite(product.id);
            }}
            className={`p-2 rounded-full backdrop-blur-md transition-all ${
              isFavorite ? 'bg-red-500 text-white' : 'bg-white/80 text-gray-900 hover:bg-white'
            }`}
            id={`fav-btn-${product.id}`}
          >
            <Heart size={18} fill={isFavorite ? 'currentColor' : 'none'} />
          </button>
          
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onToggleCompare(product);
            }}
            className={`p-2 rounded-full backdrop-blur-md transition-all ${
              isComparing ? 'bg-brand-primary text-white' : 'bg-white/80 text-gray-900 hover:bg-white'
            }`}
            id={`compare-btn-${product.id}`}
          >
            <ArrowLeftRight size={18} />
          </button>
        </div>

        {discount > 0 && (
          <div className="absolute top-3 left-3 bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-lg uppercase tracking-wider">
            {discount}% OFF
          </div>
        )}

        {!product.inStock && (
          <div className="absolute inset-0 bg-white/60 backdrop-blur-[1px] flex items-center justify-center">
            <span className="bg-gray-900 text-white text-xs font-bold px-3 py-1.5 rounded-full">OUT OF STOCK</span>
          </div>
        )}
      </div>

      <div className="p-4 flex flex-col flex-grow">
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] font-bold text-brand-accent uppercase tracking-widest">{product.brand}</span>
          <div className="flex items-center gap-1 text-xs font-medium text-gray-500">
            <Star size={12} className="text-yellow-400 fill-yellow-400" />
            <span>{product.rating}</span>
          </div>
        </div>
        
        <h3 
          className="text-sm font-semibold text-gray-900 mb-2 line-clamp-2 hover:text-brand-accent transition-colors cursor-pointer flex-grow"
          onClick={() => onSelect(product)}
        >
          {product.name}
        </h3>

        <div className="mt-auto pt-3 border-t border-gray-100 flex items-end justify-between">
          <div className="flex flex-col">
            <span className="text-[10px] text-gray-400 line-through">
              {product.originalPrice ? `$${product.originalPrice.toFixed(2)}` : ''}
            </span>
            <span className="text-lg font-bold text-gray-900">
              ${product.price.toFixed(2)}
            </span>
            <span className="text-[10px] text-gray-500 font-medium">at {product.store}</span>
          </div>
          
          <button 
            className="flex items-center gap-1.5 text-[10px] font-bold text-brand-accent border border-brand-accent/20 px-3 py-1.5 rounded-full hover:bg-brand-accent hover:text-white transition-all uppercase tracking-tighter"
            id={`alert-btn-${product.id}`}
          >
            <Bell size={12} />
            Alert
          </button>
        </div>
      </div>
    </motion.div>
  );
}
