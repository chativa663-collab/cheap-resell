import { Search, SlidersHorizontal, ChevronDown } from 'lucide-react';
import { Category } from '../types';

interface FilterBarProps {
  search: string;
  setSearch: (val: string) => void;
  category: Category | 'All';
  setCategory: (val: Category | 'All') => void;
  sortBy: string;
  setSortBy: (val: string) => void;
}

const CATEGORIES: (Category | 'All')[] = ['All', 'Suncare', 'Skincare', 'Toys', 'Tech', 'Fashion', 'Home'];

export default function FilterBar({ 
  search, 
  setSearch, 
  category, 
  setCategory,
  sortBy,
  setSortBy
}: FilterBarProps) {
  return (
    <div className="sticky top-0 z-30 bg-[var(--color-brand-bg)]/80 backdrop-blur-xl border-b border-black/5 pb-4 px-4 pt-4 flex flex-col gap-4">
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input 
          type="text"
          placeholder="Search brands or products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full bg-white border border-black/5 rounded-2xl py-3.5 pl-12 pr-4 text-sm font-medium focus:ring-2 focus:ring-brand-accent/20 focus:border-brand-accent outline-none transition-all shadow-sm"
          id="search-input"
        />
      </div>

      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        <div className="flex items-center gap-2 pr-4 border-r border-gray-200">
          <button 
            className="flex items-center gap-1.5 p-2 px-3 bg-white border border-black/5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all shrink-0"
            id="filter-settings-btn"
          >
            <SlidersHorizontal size={14} />
            Filters
          </button>
          
          <div className="relative shrink-0">
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="appearance-none bg-white border border-black/5 rounded-xl py-2 pl-3 pr-8 text-xs font-bold text-gray-600 hover:bg-gray-50 outline-none cursor-pointer"
              id="sort-select"
            >
              <option value="cheapest">Cheapest</option>
              <option value="rating">Best Rating</option>
              <option value="newest">Newest</option>
            </select>
            <ChevronDown size={14} className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400" />
          </div>
        </div>

        <div className="flex gap-2 pl-1">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-4 py-2 rounded-xl text-[11px] font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
                category === cat 
                  ? 'bg-brand-primary text-white shadow-lg shadow-black/10' 
                  : 'bg-white text-gray-500 border border-black/5 hover:bg-gray-50'
              }`}
              id={`cat-filter-${cat.toLowerCase()}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
