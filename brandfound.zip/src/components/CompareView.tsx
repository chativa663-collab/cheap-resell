import { X, ArrowLeftRight } from 'lucide-react';
import { Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface CompareViewProps {
  comparingProducts: Product[];
  onRemove: (id: string) => void;
  onClear: () => void;
}

export default function CompareView({ comparingProducts, onRemove, onClear }: CompareViewProps) {
  if (comparingProducts.length === 0) return null;

  return (
    <div className="fixed bottom-24 left-4 right-4 z-40">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="bg-brand-primary text-white rounded-2xl shadow-2xl overflow-hidden"
        id="compare-view-bar"
      >
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ArrowLeftRight size={18} />
            <span className="text-xs font-bold uppercase tracking-widest">Comparison ({comparingProducts.length})</span>
          </div>
          <button 
            onClick={onClear}
            className="text-[10px] font-bold uppercase tracking-widest text-white/60 hover:text-white transition-colors"
            id="clear-compare-btn"
          >
            Clear All
          </button>
        </div>

        <div className="p-4 flex gap-4 overflow-x-auto no-scrollbar">
          {comparingProducts.map(p => (
            <div key={p.id} className="relative shrink-0 w-16 h-16 rounded-xl overflow-hidden border border-white/20">
              <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
              <button 
                onClick={() => onRemove(p.id)}
                className="absolute top-1 right-1 p-0.5 bg-black/60 rounded-full text-white"
                id={`remove-compare-${p.id}`}
              >
                <X size={10} />
              </button>
            </div>
          ))}
          
          {comparingProducts.length < 3 && (
            <div className="shrink-0 w-16 h-16 rounded-xl border-2 border-dashed border-white/10 flex items-center justify-center text-white/20">
              <span className="text-[10px] font-bold">+</span>
            </div>
          )}
        </div>

        {comparingProducts.length >= 2 && (
          <div className="px-4 pb-4">
            <button 
              className="w-full py-2.5 bg-white text-brand-primary rounded-xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-gray-100 transition-all"
              id="analyze-compare-btn"
            >
              Analyze Comparison
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
