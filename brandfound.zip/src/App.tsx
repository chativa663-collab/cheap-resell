import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Menu, 
  Heart, 
  Bell, 
  ChevronRight, 
  Star, 
  Filter, 
  X,
  ArrowUpDown,
  Laptop,
  Puzzle,
  Sparkles,
  ShoppingBag,
  Gamepad2,
  Home as HomeIcon,
  Plus
} from 'lucide-react';
import { MOCK_PRODUCTS } from './data/mockProducts';
import { Product, Category } from './types';

const CATEGORIES: { id: Category; label: string; icon: any }[] = [
  { id: 'Tech', label: 'Tech', icon: Laptop },
  { id: 'Toys', label: 'Toys', icon: Puzzle },
  { id: 'Beauty', label: 'Beauty', icon: Sparkles },
  { id: 'Fashion', label: 'Fashion', icon: ShoppingBag },
  { id: 'Gaming', label: 'Gaming', icon: Gamepad2 },
  { id: 'Home', label: 'Home', icon: HomeIcon },
];

export default function App() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [compareList, setCompareList] = useState<string[]>([]);
  const [showCompare, setShowCompare] = useState(false);
  const [priceAlerts, setPriceAlerts] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [maxPrice, setMaxPrice] = useState(1000);
  const [selectedStores, setSelectedStores] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'price-low' | 'price-high' | 'rating'>('rating');

  const STORES = useMemo(() => Array.from(new Set(MOCK_PRODUCTS.map(p => p.store))), []);

  const filteredProducts = useMemo(() => {
    let result = MOCK_PRODUCTS.filter((p) => {
      const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                           p.brand.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      const matchesPrice = p.price <= maxPrice;
      const matchesStore = selectedStores.length === 0 || selectedStores.includes(p.store);
      return matchesSearch && matchesCategory && matchesPrice && matchesStore;
    });

    if (sortBy === 'price-low') result.sort((a, b) => a.price - b.price);
    if (sortBy === 'price-high') result.sort((a, b) => b.price - a.price);
    if (sortBy === 'rating') result.sort((a, b) => b.rating - a.rating);

    return result;
  }, [search, selectedCategory, sortBy, maxPrice, selectedStores]);

  const toggleFavorite = (id: string) => {
    setFavorites(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const toggleCompare = (id: string) => {
    setCompareList(prev => prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]);
  };

  const toggleAlert = (id: string) => {
    setPriceAlerts(prev => prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]);
  };

  return (
    <div className="min-h-screen bg-[var(--color-brand-bg)]">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 flex flex-col pt-4">
        <div className="flex items-center justify-between px-4 pb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center shadow-lg transform -rotate-6">
              <span className="text-white font-bold text-lg">B</span>
            </div>
            <h1 className="text-xl font-black tracking-tight text-black">BrandFound</h1>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowCompare(!showCompare)}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors relative"
              id="compare-toggle-btn"
            >
              <ArrowUpDown className="w-5 h-5 text-gray-700" />
              {compareList.length > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-black text-white text-[10px] font-bold flex items-center justify-center rounded-full border-2 border-white shadow-sm">
                  {compareList.length}
                </span>
              )}
            </button>
            <div className="relative">
              <button className="p-2 hover:bg-gray-100 rounded-full relative">
                <Bell className="w-5 h-5 text-gray-700" />
                {priceAlerts.length > 0 && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border border-white" />
                )}
              </button>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-full">
              <Menu className="w-6 h-6 text-gray-700" />
            </button>
          </div>
        </div>

        {/* Search Bar */}
        <div className="px-4 pb-4">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-black transition-colors" />
            <input 
              type="text" 
              placeholder="Search premium brands..."
              className="w-full bg-gray-100 border-2 border-transparent rounded-2xl py-3.5 pl-11 pr-4 focus:bg-white focus:border-black/5 focus:ring-4 focus:ring-black/5 outline-none transition-all placeholder:text-gray-400 font-medium"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              id="search-input"
            />
          </div>
        </div>

        {/* Category Scroll */}
        <div className="flex overflow-x-auto no-scrollbar gap-2 px-4 pb-4">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-6 py-2.5 rounded-2xl whitespace-nowrap text-sm font-bold tracking-tight transition-all duration-300 ${
              selectedCategory === 'All' 
                ? 'bg-black text-white shadow-xl shadow-black/20 scale-105' 
                : 'bg-white border border-gray-100 text-gray-500 hover:border-gray-300'
            }`}
          >
            All Items
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`flex items-center gap-2.5 px-5 py-2.5 rounded-2xl whitespace-nowrap text-sm font-bold tracking-tight transition-all duration-300 ${
                selectedCategory === cat.id 
                  ? 'bg-black text-white shadow-xl shadow-black/20 scale-105' 
                  : 'bg-white border border-gray-100 text-gray-500 hover:border-gray-300'
              }`}
            >
              <cat.icon className={`w-4 h-4 ${selectedCategory === cat.id ? 'text-white' : 'text-gray-400'}`} />
              {cat.label}
            </button>
          ))}
        </div>
      </header>

      {/* Hero Tip */}
      <div className="px-4 py-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden bg-gradient-to-br from-black to-gray-800 rounded-[2.5rem] p-6 text-white shadow-2xl shadow-black/20"
        >
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-3">
              <span className="bg-white/20 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10">Daily Spotlight</span>
              <span className="text-white/40 text-[10px] font-bold uppercase tracking-widest">• 2h remaining</span>
            </div>
            <h3 className="text-2xl font-black leading-tight mb-2 tracking-tighter">Sony XM5 Headphones</h3>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-3xl font-black text-[var(--color-brand-accent)]">$298</span>
              <span className="text-white/40 line-through text-sm">$399</span>
            </div>
            <p className="text-white/60 text-xs leading-relaxed max-w-[200px] mb-6">Unbeatable price for the industry's best noise cancelling tech.</p>
            <button className="bg-white text-black px-6 py-3 rounded-2xl font-black text-sm hover:scale-105 transition-transform">Get Deal</button>
          </div>
          {/* Decorative element */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full blur-3xl -translate-y-12 translate-x-12" />
        </motion.div>
      </div>

      {/* Main Content */}
      <main className="px-4 pb-32">
        <div className="flex items-center justify-between mb-6 px-1">
          <div className="flex flex-col">
            <h2 className="text-xl font-black tracking-tight text-gray-900 leading-none">Curated Picks</h2>
            <span className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">{filteredProducts.length} Results</span>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowFilters(true)}
              className="flex items-center gap-2 bg-white border border-gray-100 rounded-xl px-4 py-2 shadow-sm hover:border-gray-300 transition-colors"
            >
              <Filter className="w-3.5 h-3.5 text-gray-400" />
              <span className="text-xs font-black uppercase tracking-widest text-black">Filters</span>
              {(maxPrice < 1000 || selectedStores.length > 0) && (
                <span className="w-2 h-2 bg-black rounded-full" />
              )}
            </button>
            <div className="flex items-center gap-2 bg-white border border-gray-100 rounded-xl px-3 py-2 shadow-sm">
              <ArrowUpDown className="w-3.5 h-3.5 text-gray-400" />
              <select 
                className="bg-transparent border-none focus:ring-0 cursor-pointer font-bold text-xs text-black uppercase tracking-wider"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
              >
                <option value="rating">Popular</option>
                <option value="price-low">Cheapest</option>
                <option value="price-high">Expensive</option>
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <AnimatePresence mode="popLayout">
            {filteredProducts.map((product) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                key={product.id}
                className="group relative bg-white rounded-[2.5rem] overflow-hidden border border-black/5 flex flex-col p-2.5 h-full transition-all hover:shadow-xl hover:shadow-black/5"
              >
                {/* Image Container */}
                <div className="relative aspect-square rounded-[2rem] overflow-hidden bg-gray-50">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div className="absolute top-2.5 right-2.5 flex flex-col gap-2">
                    <button 
                      onClick={() => toggleFavorite(product.id)}
                      className={`p-2.5 rounded-2xl backdrop-blur-xl transition-all duration-300 ${
                        favorites.includes(product.id)
                          ? 'bg-red-500 text-white shadow-lg shadow-red-200'
                          : 'bg-white/90 text-gray-400 hover:text-black hover:bg-white'
                      }`}
                    >
                      <Heart className={`w-4 h-4 ${favorites.includes(product.id) ? 'fill-current' : ''}`} />
                    </button>
                    <button 
                      onClick={() => toggleCompare(product.id)}
                      className={`p-2.5 rounded-2xl backdrop-blur-xl transition-all duration-300 ${
                        compareList.includes(product.id)
                          ? 'bg-black text-white shadow-lg shadow-black/20'
                          : 'bg-white/90 text-gray-400 hover:text-black hover:bg-white'
                      }`}
                    >
                      <ArrowUpDown className="w-4 h-4" />
                    </button>
                  </div>
                  {product.originalPrice && (
                    <div className="absolute top-2.5 left-2.5 bg-black text-white text-[9px] uppercase tracking-[0.15em] font-black px-2.5 py-1.5 rounded-xl backdrop-blur-md">
                      SAVE {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
                    </div>
                  )}
                  {!product.inStock && (
                    <div className="absolute inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center p-4">
                      <span className="bg-black text-white px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl">WAITLIST</span>
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-3.5 flex flex-col flex-grow">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[9px] uppercase font-black tracking-[0.2em] text-gray-400">{product.brand}</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-[10px] font-black">{product.rating}</span>
                    </div>
                  </div>
                  <h3 className="text-sm font-bold line-clamp-2 leading-snug mb-3 text-gray-900 min-h-[2.5rem] tracking-tight">{product.name}</h3>
                  
                  <div className="mt-auto">
                    <div className="flex items-baseline gap-2 mb-3">
                      <span className="text-xl font-black text-black tracking-tighter">${product.price.toFixed(0)}<span className="text-xs">.{product.price.toFixed(2).split('.')[1]}</span></span>
                      {product.originalPrice && (
                        <span className="text-[10px] text-gray-400 font-bold line-through tracking-tight">${product.originalPrice.toFixed(0)}</span>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                         <div className="w-4 h-4 bg-green-100 rounded-full flex items-center justify-center">
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                         </div>
                         <span className="text-[10px] font-bold text-gray-600 tracking-tight">{product.store}</span>
                      </div>
                      <button 
                         onClick={() => toggleAlert(product.id)}
                        className={`p-2 rounded-xl transition-all duration-300 ${
                          priceAlerts.includes(product.id) 
                            ? 'bg-black text-white shadow-lg shadow-black/10' 
                            : 'bg-gray-50 text-gray-300 hover:bg-gray-100 hover:text-black'
                        }`}
                        title="Set Price Alert"
                      >
                        <Bell className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredProducts.length === 0 && (
          <div className="py-32 text-center">
            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6 border border-gray-100">
              <Search className="w-10 h-10 text-gray-200" />
            </div>
            <h3 className="font-black text-xl text-gray-900 tracking-tight leading-none mb-2">Nothing found</h3>
            <p className="text-gray-400 text-sm font-medium px-12 leading-relaxed">No premium deals match your search criteria. Try broadening your exploration.</p>
          </div>
        )}
      </main>

      {/* Comparison Overlay */}
      <AnimatePresence>
        {showCompare && compareList.length > 0 && (
          <motion.div 
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[100] bg-white flex flex-col"
          >
            <div className="px-6 py-6 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-black tracking-tight">Comparison</h2>
                <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">{compareList.length} items selected</p>
              </div>
              <button 
                onClick={() => setShowCompare(false)} 
                className="p-3 bg-gray-50 hover:bg-gray-100 rounded-[1.25rem] transition-colors"
                id="close-compare-btn"
              >
                <X className="w-6 h-6 text-black" />
              </button>
            </div>
            <div className="flex-grow overflow-x-auto p-6 flex gap-8 no-scrollbar bg-gray-50/50">
              {compareList.map(id => {
                const p = MOCK_PRODUCTS.find(x => x.id === id);
                if (!p) return null;
                return (
                  <motion.div 
                    layout
                    key={id} 
                    className="w-[300px] flex-shrink-0 flex flex-col gap-6 bg-white p-6 rounded-[3rem] border border-black/5 shadow-xl shadow-black/5 h-fit"
                  >
                    <div className="relative aspect-square rounded-[2rem] overflow-hidden bg-gray-50 border border-gray-100">
                      <img src={p.image} className="w-full h-full object-cover" />
                      <button 
                        onClick={() => toggleCompare(id)}
                        className="absolute top-3 right-3 p-2 bg-black/60 text-white rounded-2xl hover:bg-black backdrop-blur-md transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                    <div className="space-y-6">
                      <div>
                        <span className="text-[10px] uppercase font-black text-gray-400 tracking-[0.2em] mb-1 block">{p.brand}</span>
                        <h3 className="font-black text-xl leading-tight text-gray-900">{p.name}</h3>
                      </div>
                      
                      <div className="py-6 border-y border-gray-100 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Live Deal</span>
                          <span className="font-black text-black text-2xl tracking-tighter">${p.price.toFixed(2)}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Compare to</span>
                          <span className="line-through text-gray-400 font-bold text-sm tracking-tight">${p.originalPrice?.toFixed(2)}</span>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <span className="text-[10px] font-black uppercase text-black tracking-[0.2em] block">Technical Specs</span>
                        <div className="grid grid-cols-1 gap-4">
                          {Object.entries(p.specs).map(([key, value]) => (
                            <div key={key} className="flex flex-col gap-1 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                              <span className="text-[9px] uppercase text-gray-400 font-black tracking-widest">{key}</span>
                              <span className="text-sm font-bold text-gray-900">{value}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <button className="w-full bg-black text-white py-5 rounded-[1.5rem] font-black text-sm flex items-center justify-center gap-2 hover:bg-gray-900 shadow-xl shadow-black/10 transition-all hover:-translate-y-1 active:translate-y-0">
                        View Item Detail
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                );
              })}
              {compareList.length < 3 && (
                <div className="w-[300px] flex-shrink-0 flex items-center justify-center border-3 border-dashed border-gray-200 rounded-[3rem] bg-white transition-colors hover:border-gray-300">
                  <div className="text-center p-8">
                    <div className="w-16 h-16 bg-gray-50 rounded-3xl flex items-center justify-center mx-auto mb-4">
                      <Plus className="w-8 h-8 text-gray-300" />
                    </div>
                    <p className="text-sm text-gray-400 font-black uppercase tracking-widest leading-relaxed">Add to Compare</p>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter Drawer */}
      <AnimatePresence>
        {showFilters && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFilters(false)}
              className="fixed inset-0 z-[110] bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 z-[120] bg-white rounded-t-[3rem] p-8 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-black tracking-tight">Discovery Filters</h2>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Adjust to find your perfect deal</p>
                </div>
                <button 
                  onClick={() => setShowFilters(false)}
                  className="p-3 bg-gray-50 hover:bg-gray-100 rounded-2xl transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="space-y-8 pb-12">
                {/* Price Range */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-widest text-black">Maximum Price</span>
                    <span className="text-lg font-black tracking-tighter">${maxPrice}</span>
                  </div>
                  <input 
                    type="range"
                    min="10"
                    max="1000"
                    step="10"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(Number(e.target.value))}
                    className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-black"
                  />
                  <div className="flex justify-between text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    <span>$10</span>
                    <span>$1000+</span>
                  </div>
                </div>

                {/* Stores */}
                <div className="space-y-4">
                  <span className="text-[10px] font-black uppercase tracking-widest text-black block">Preferred Stores</span>
                  <div className="flex flex-wrap gap-2">
                    {STORES.map(store => (
                      <button
                        key={store}
                        onClick={() => {
                          setSelectedStores(prev => 
                            prev.includes(store) ? prev.filter(s => s !== store) : [...prev, store]
                          );
                        }}
                        className={`px-4 py-2 rounded-xl text-xs font-bold tracking-tight border transition-all ${
                          selectedStores.includes(store)
                            ? 'bg-black text-white border-black shadow-lg shadow-black/10 scale-105'
                            : 'bg-white text-gray-500 border-gray-100 hover:border-gray-300'
                        }`}
                      >
                        {store}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 flex gap-3">
                  <button 
                    onClick={() => {
                      setMaxPrice(1000);
                      setSelectedStores([]);
                    }}
                    className="flex-1 py-4 rounded-2xl font-black text-sm text-gray-400 hover:text-black transition-colors border border-gray-100"
                  >
                    Reset
                  </button>
                  <button 
                    onClick={() => setShowFilters(false)}
                    className="flex-[2] bg-black text-white py-4 rounded-2xl font-black text-sm shadow-xl shadow-black/20 hover:scale-[1.02] transition-transform"
                  >
                    Show {filteredProducts.length} Results
                  </button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-[60] px-6 pb-8 pt-4">
        <div className="max-w-md mx-auto bg-black/90 backdrop-blur-2xl rounded-[2.5rem] p-2.5 flex items-center justify-between shadow-2xl shadow-black/40 border border-white/10">
          <button className="flex flex-col items-center gap-1 text-white flex-1 py-3 group">
            <HomeIcon className="w-6 h-6 transition-transform group-active:scale-90" />
            <span className="text-[8px] font-black uppercase tracking-[0.2em]">Home</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/40 hover:text-white transition-colors flex-1 py-3 group relative">
            <Heart className={`w-6 h-6 transition-transform group-active:scale-90 ${favorites.length > 0 ? 'text-red-400 fill-red-400' : ''}`} />
            <span className="text-[8px] font-black uppercase tracking-[0.2em]">Favs</span>
            {favorites.length > 0 && <span className="absolute top-2 right-1/2 -mr-5 w-4 h-4 bg-red-500 text-white text-[8px] font-black flex items-center justify-center rounded-full border-2 border-black">{favorites.length}</span>}
          </button>
          <button 
            onClick={() => setShowCompare(true)}
            className="flex flex-col items-center gap-1 text-white/40 hover:text-white transition-colors flex-1 py-3 group"
          >
            <ArrowUpDown className="w-6 h-6 transition-transform group-active:scale-90" />
            <span className="text-[8px] font-black uppercase tracking-[0.2em]">Compare</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/40 hover:text-white transition-colors flex-1 py-3 group">
            <Bell className="w-6 h-6 transition-transform group-active:scale-90" />
            <span className="text-[8px] font-black uppercase tracking-[0.2em]">Alerts</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
